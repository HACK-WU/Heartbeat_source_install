#!/bin/sh

echo Please run bootstrap instead of autogen.sh
echo

exit 1

